package jp.lifematics.misusecase.view;

import jp.lifematics.misusecase.Knowledge;

public interface KnowledgeSelectedListener {
    void selected(Knowledge knowledge);
}
