package jp.lifematics.misusecase;


import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

public class Activator implements BundleActivator {

	public void start(BundleContext context) {
	}

	public void stop(BundleContext context) {
	}
	
}
