package jp.lifematics.misusecase.view;

import jp.lifematics.misusecase.Knowledge;

public interface KnowledgeActionListener {
    void focus(Knowledge knowledge);
    void insert(Knowledge knowledge);
}
