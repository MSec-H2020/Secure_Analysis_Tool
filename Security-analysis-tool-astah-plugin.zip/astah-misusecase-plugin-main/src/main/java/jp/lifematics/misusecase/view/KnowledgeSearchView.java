package jp.lifematics.misusecase.view;

import jp.lifematics.misusecase.Knowledge;
import jp.lifematics.misusecase.KnowledgeRepository;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Set;

public class KnowledgeSearchView extends JPanel {

    private static class KnowledgeEntry extends JPanel {

        private Knowledge knowledge = null;
        private KnowledgeSelectedListener listener = null;

        public KnowledgeEntry( Knowledge knowledge) {
            this.knowledge = knowledge;
            this.initComponents();
        }

        public void setKnowledgeSelectedListener(KnowledgeSelectedListener listener) {
            this.listener = listener;
        }

        public Knowledge getKnowledge() {
            return knowledge;
        }

        private void initComponents() {
            setLayout(new BorderLayout());
            JLabel label = new JLabel(knowledge.getName());
            label.setForeground(Color.BLUE);
            add(label, BorderLayout.NORTH);
            label.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent mouseEvent) {
                    if (listener != null) {
                        listener.selected(knowledge);
                    }
                }
            });

            JTextArea body = new JTextArea(knowledge.getDescription());
            body.setLineWrap(true);
            body.setEditable(false);
            add(body, BorderLayout.CENTER);
            body.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent mouseEvent) {
                    if (listener != null) {
                        listener.selected(knowledge);
                    }
                }
            });

            setPreferredSize(new Dimension(400, 50));
        }
    }

    private KnowledgeSelectedListener listener = null;

    private Set<Knowledge> knowledges;

    private JPanel searchPanel = null;
    private JTextField keywordField = null;

    private JPanel resultPanel = null;

    public KnowledgeSearchView() {
        this.initComponents();
    }

    public void setKnowledgeSelectedListener(KnowledgeSelectedListener listener) {
        this.listener = listener;
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        searchPanel = new JPanel();
        keywordField = new JTextField(32);
        searchPanel.add(keywordField);
        JButton button = new JButton("Search");
        searchPanel.add(button);
        add(searchPanel, BorderLayout.NORTH);

        button.addActionListener(actionEvent -> {
            knowledges = KnowledgeRepository.getInstance().search(keywordField.getText());
            updateResultPanel();
        });

        resultPanel = new JPanel();
        BoxLayout layout = new BoxLayout(resultPanel, BoxLayout.Y_AXIS);
        resultPanel.setLayout(layout);

        JScrollPane scrollPane = new JScrollPane(resultPanel);
        add(scrollPane, BorderLayout.CENTER);
    }

    private void updateResultPanel() {
        if (knowledges == null) {
            return;
        }

        resultPanel.removeAll();
        for (Knowledge knowledge : knowledges) {
            KnowledgeEntry entry = new KnowledgeEntry(knowledge);
            entry.setKnowledgeSelectedListener(new KnowledgeSelectedListener() {
                @Override
                public void selected(Knowledge knowledge) {
                    showKnowledge(knowledge);
                }
            });
            resultPanel.add(entry);
            entry.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent mouseEvent) {
                    KnowledgeEntry entry = (KnowledgeEntry)mouseEvent.getSource();
                    showKnowledge(entry.getKnowledge());
                }
            });
            entry.setVisible(true);
        }
        resultPanel.updateUI();
    }

    private void showKnowledge(Knowledge knowledge)
    {
        if (listener != null) {
            listener.selected(knowledge);
        }
    }
}
