package jp.lifematics.misusecase.view;

import jp.lifematics.misusecase.Knowledge;

import javax.swing.*;

public class KnowledgeView extends JSplitPane {

    private KnowledgeSearchView knowledgeSearchView = null;
    private KnowledgeDetailsView knowledgeDetailsView = null;

    private KnowledgeActionListener listener = null;

    public KnowledgeView() {
        super(JSplitPane.VERTICAL_SPLIT);

        knowledgeSearchView = new KnowledgeSearchView();
        knowledgeSearchView.setKnowledgeSelectedListener(new KnowledgeSelectedListener() {
            @Override
            public void selected(Knowledge knowledge) {
                knowledgeDetailsView.setKnowledge(knowledge);
            }
        });

        knowledgeDetailsView = new KnowledgeDetailsView();
        knowledgeDetailsView.setKnowledgeActionListener(new KnowledgeActionListener() {
            @Override
            public void focus(Knowledge knowledge) {
                if (listener != null) {
                    listener.focus(knowledge);
                }
            }
            @Override
            public void insert(Knowledge knowledge) {
                if (listener != null) {
                    listener.insert(knowledge);
                }
            }
        });

        setTopComponent(knowledgeSearchView);
        setBottomComponent(knowledgeDetailsView);
        setDividerLocation(200);
    }

    void setKnowledgeActionListener(KnowledgeActionListener listener) {
        this.listener = listener;
    }
}
