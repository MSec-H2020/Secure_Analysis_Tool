package jp.lifematics.misusecase;

import java.util.Set;
import java.util.UUID;

public class Knowledge {

    private String id;
    private String name;
    private String type;
    private String category;
    private String description;
    private String source;
    private Set<String> inherit;
    private Set<String> related;

    public Knowledge() {
        this.id = UUID.randomUUID().toString();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Set<String> getInherit() {
        return inherit;
    }

    public void setInherit(Set<String> inherit) {
        this.inherit = inherit;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Set<String> getRelated() {
        return related;
    }

    public void setRelated(Set<String> related) {
        this.related = related;
    }
}
