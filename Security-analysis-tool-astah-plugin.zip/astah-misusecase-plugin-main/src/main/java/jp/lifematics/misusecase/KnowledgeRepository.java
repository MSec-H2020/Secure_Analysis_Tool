package jp.lifematics.misusecase;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class KnowledgeRepository {

    private static class SingletonHolder {
        private static final KnowledgeRepository INSTANCE = new KnowledgeRepository();
    }

    public static KnowledgeRepository getInstance() {
        return SingletonHolder.INSTANCE;
    }

    private Set<Knowledge> knowledges = null;

    private KnowledgeRepository() {
        knowledges = loadKnowledges();
    }

    private Set<Knowledge> loadKnowledges()
    {
        Set<Knowledge> knowledges = null;

        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream("knowledges/knowledges.json");
        if (inputStream != null) {
            try {
                StringWriter writer = new StringWriter();
                IOUtils.copy(inputStream, writer, "UTF-8");
                String json = writer.toString();

                final ObjectMapper mapper = new ObjectMapper();
                knowledges = mapper.readValue(json, new TypeReference<Set<Knowledge>>() {});
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return knowledges;
    }

    public Set<Knowledge> getKnowledges() {
        return knowledges;
    }

    public Set<String> getCategories() {
        Set<String> categories = new HashSet<String>();
        for (Knowledge knowledge: knowledges) {
            categories.add(knowledge.getCategory());
        }
        return categories;
    }

    public Set<Knowledge> search(String keyword) {
        return search(keyword, false);
    }

    public Set<Knowledge> search(String keyword, boolean exactMatch) {
        Set<Knowledge> result = new HashSet<Knowledge>();
        for (Knowledge knowledge: knowledges) {
            if (exactMatch) {
                if (knowledge.getName().equals(keyword)) {
                    result.add(knowledge);
                }
            } else {
                if (knowledge.getName().contains(keyword)) {
                    result.add(knowledge);
                }
            }
        }

        return result;
    }

}
