package jp.lifematics.misusecase;

import static org.junit.Assert.*;

import org.junit.Test;


public class TemplateActionTest {
	
	@Test
	public void testname() throws Exception {
		
	}

}


